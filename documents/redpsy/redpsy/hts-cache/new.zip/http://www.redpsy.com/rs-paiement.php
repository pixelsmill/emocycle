<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Inscription à Savoir ressentir</title>
        <style>
            .achatcc {
/*      remplacer "block" par "none" si les cartes ne sont pas pertinentes */
                display: block;
            }
        </style>
                <link rel="stylesheet" type="text/css" href="/sept2016/normal.css">
        <script>
            function jemail(user, domain, suffix){
                document.write('<a href="' + 'mailto:' + user + '@' + domain + '.' + suffix + '">' + user + '@' + domain + '.' + suffix + '</a>');
            }
        </script>
    </head>
    <body>
        <div id="contenant">
            <div id="entete">
                <a href='/index.php'><img class="logo" src="http://www.infopsy.com/red/bandeau/logo/redediteur.jpg"
                    style="border-style: none" alt="Logo ReD éditeur" height="69" width="441"></a>
                <p class="red">
                    Ressources en Développement<br>
                    Les psychologues humanistes
                </p>
                <img class="barmauv" src="http://www.infopsy.com/red/barmauv.gif" height="3" width="300" alt="---------------">
            </div>
    <div id="colndroite">
    </div>
    <div id="contenu">
        <div id="titre">
            <h1>Inscription au programme Savoir ressentir</h1>
            <h3>Paiement par carte de crédit ou carte bancaire</h3>
        </div>
        <!-- ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici -->
<br>
<noscript><h2> ATTENTION<br>
    !!! Pour le calcul de la commande, JavaScript doit être activé !!!</h2>
</noscript>
<!-- Commande-->
<div style="margin-left: 100px;">
	<!--
// déplacer la fin de commentaire à la fin pour un message nul,
//	ou après cette ligne pour l'afficher.
<br>
<font color="RED" size="+1">IMPORTANT :
Jusqu'au 22 juillet exceptionellement, les réponses à vos leçons ne vous seront
envoyées qu'une fois par semaine, les mardis. Veuillez nous en excuser.
</font>
<br>
-->

</div>
	<br>
    <form id="nombres" action="achats/cc-achat.php" method="post">
        <table style="margin-left:150px;" id="produits" border="0">
            <tr><td></td><td><h2>Cochez la case ci-dessous</h2></td></tr>
                
            <tr><td ><input type="checkbox" name="prod1" value="14" required="required">
                    <input type="hidden" name="nbprod" value="1"></td><td>Je désire
            effectuer mon paiement pour suivre le 
            <a href="http://redpsy.com/editions/sro.html">Programme Savoir Ressentir</a>            par Internet.</td></tr><tr><td></td><td>Ce paiement couvre les trois cours, et les 24 leçons du Programme</td></tr>
            <tr><td></td><td>
            <h2>Cliquez le bouton "effectuer mon paiement"</h2></td></tr>
            <tr><td></td><td class="centre"><input type="hidden" name="nombre1" value="1">
                    <input type="submit" value="effectuer mon paiement"></td></tr>
        </table>
    </form>
    </div>
                <div id="ventecc" class="achatcc">
                <p class="accept"><b>Nous acceptons:</b><br>
                <img id="cartes" src="http://www.redpsy.com/images/logosCC.jpg" alt="Visa, Master Card, Am.Express"><br>
                    <a href="http://www.redpsy.com/cc-securite.html">
                        Nos politiques pour les cartes de crédit</a><br></p>
                    <p class="prob">Si vous éprouvez des difficultés avec votre commande, <br>
                    vous pouvez communiquer rapidement avec nous à cette adresse: <br>
                    <script>
                        <!-- Begin
                        jemail("commandes", "infopsy", "com");
                        // End -->
                    </script>
                </p>
            </div>
            <div id="pied"><br>
                <center><a href="#"><img src="http://www.infopsy.com/red/1mup.gif" border="0"></a></center>
                <img class="barfin" src="http://www.infopsy.com/red/barmauv.gif" height="5" width="500" alt="---------------">
                <div id="copyright">
                    <img src="http://www.infopsy.com/red/redlogoc.gif" alt="ReD" width="49">
                    <div id="droits"><p class="droits">
                            Tous droits réservés © 2000-2016 par Ressources en Développement
                        </p></div>
                </div>
            </div>
        </div>    
    </body>
</html>

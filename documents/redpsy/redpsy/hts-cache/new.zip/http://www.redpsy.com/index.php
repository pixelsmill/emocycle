<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Auto-développement - psychologues humanistes (Montréal)</title>
        <meta name="description" content="Nombreuses ressources pour vous aider dans votre développement personnel et/ou professionnel: articles, outils, Guide des émotions, etc. Par des psychologues humanistes spécialisés en Auto-développement. Montréal.">
        <meta name="keywords" content="psychologue Montréal, psychothérapeute Montréal, psychologues, psychologie, psychologue humaniste, ressources, aide, développement personnel, croissance personnelle, cheminement personnel, humanistes, services psychologiques, psychothérapie, thérapie, stress, outils, intervention psychologique, auto-développement, autodéveloppement, Karène Larocque, Martine Mignot, Michelle Larivey, Jean Garneau, magazine électronique, ezine, émotions, redpsy, formation, professionnel, Ezine, sentiments, informations, épanouissement personnel, bien-être, mieux-être, ressentir, consultation, difficulté, problème, solution, moyens, trucs, spécialistes psychologist, humanistic, psychology, therapy, psychotherapy">
        <link rel="SHORTCUT ICON" href="http://www.redpsy.com/red.ico"></head>
    <link rel="stylesheet" type="text/css" href="./sept2016/menured.css">
    <body>
        <div style="text-align: right;margin-right: 15px;">
            <a href="plan.html">Plan du site</a>&nbsp;&nbsp;&nbsp;
            <a href="planred.html">Communiquer avec nous</a>&nbsp;&nbsp;&nbsp;
            <a href="recherche.html">Rechercher sur notre site</a>            
        </div>
    <center>
        <table bgcolor="#ffffff" border="0" cellpadding="10" width="85%">

            <tr>
                <td>
            <center><img src="http://www.infopsy.com/red/bandeau/logo/a-dlogo.jpg" alt="Auto-développement" border="0" height="69" width="554"><br>
                <font color="#990066" size="3"><b>Le
                    site officiel de</b></font>
                <font style="font-weight: bold;" color="#990066" size="3">Ressources
                en Développement</font><br>
                <font style="font-weight: bold;" color="#990066">Les
                psychologues
                humanistes</font><br>
                <br>
                <img src="http://www.infopsy.com/red/barmauv.gif" height="4" width="400">
            </center>
            </td>
            </tr>
        </table>
        <!-- ici - ici - ici insert Jean -->
        <center> <font size="-1">
            Ce site est consacré à la <a href="http://www.redpsy.com/red.html#orientations">psychologie
                humaniste</a>. Il vous sera utile si vous recherchez
            des ressources francophones pour soutenir votre développement personnel
            ou professionnel. 
            <br>
            Vous trouverez ici les écrits de psychologues spécialisés en
            <a href="http://www.redpsy.com/red.html#autodevel">Auto-développement</a>
            ainsi que divers outils pour vous aider dans la recherche de
            solutions aux difficultés de votre vie.
            </font></center>
        <br>
        <!-- Fin insert Jean Garneau -->
        <!--
                insertion du message hebdomadaire
        -->
        <div style="background-color: #dddddd;">
            <!--
 * Contient le code html qui sera affiché sur la page d'accueil du site.
-->
<p style="font-size: 20px;text-align: justify;padding: 10px 100px;">
     <h3>Le site de Redpsy - Autodéveloppement est remis à jour.</h3>
Le site est actuellement en test. Il est possible que certains liens aient échappé à notre attention et ne fonctionnent pas normalement. Excusez-nous pour les inconvients engendrés Vous pouvez nous en avertir l'adresse suivante :
<a href="mailto:alertes@redpsy.com">alertes@redpsy.com</a>
<br><br>
Un nouveau CD-audio comportant de larges extraits du livre ''Le défi des relations'' est disponible sur notre site.<br>
<center><img
 src="http://infopsy.com/red/bandeau/transfertCDtu.jpg"
 alt="CD Le défi des relations" border="0" height="100"
 hspace="5" vspace="3" width="72"></center>
            <center><font size="-2">2013 éditions
Alexandre Stanké inc<br>
<font size="-2"><a href="http://www.redpsy.com/editions/transfert.html#cd"><h3>Commander</h3></a></font></center>

</p>
        </div><font size="-1">
        <!--
                menu général
        -->
        <DIV id=menured style="text-align: center">
    <table style="margin: auto"><tr><td>
                <UL class=niveau1>
                    <LI class="niv1">à propos 
                        <UL class=niveau2>
                            <LI><A href="planred.html"> 
                                    Qui est ReD ?</A></li>
                            <LI><A href="plan.html"> 
                                    Plan du site</A></li>
                            <LI><A href="copyright.html"> 
                                    copyright</A></li> 
                            <LI><A href="google.shtml"> 
                                    Publicités Google</A></li> 
                        </UL>
                    </LI>
                </UL>
            </TD><td>
                <UL class=niveau1>
                    <LI class="niv1"><A href="#publications">
                            publications</A>
                        <UL class=niveau2>
                            <LI><A href="#livres"> 
                                    Livres</A>
                                <UL class=niveau3>
                                    <LI><A href="cc-livres.php">
                                            Commander sur Internet</A></LI>
                                    <LI><A href="p-livres.php">
                                            Commander par la poste</A></LI>
                                </UL>
                            </li>
                            <LI><A href="#prog"> 
                                    Savoir Ressentir</A>
                                <UL class=niveau3>
                                    <LI><A href="cc-programme.php">
                                            Commander sur Internet</A></LI>
                                    <LI><A href="p-programme.php">
                                            Commander par la poste</A></LI>
                                </UL>
                            </li>
                            <LI><A href="#cd"> 
                                    Livres audio CD</A>
                                <UL class=niveau3>
                                    <LI><A href="cc-livres.php">
                                            Commander sur Internet</A></LI>
                                    <LI><A href="p-livres.php">
                                            Commander par la poste</A></LI>
                                </UL>
                            </li> 
                        </UL>
                    </LI>
                </UL>
            </TD><td>
                <UL class=niveau1>
                    <LI class="niv1">services
                        <UL class=niveau2>
                            <LI><A href="therapie.html#individuelle"> 
                                    Psychologie individuelle</A></li>
                            <LI><A href="therapie.html#couple"> 
                                    Psychologie conjugale</A></li>
                            <LI><A href="./editions/sro.html"> 
                                    Savoir ressentir online</A></li>
                            <LI><A href="conferencesat.html"> 
                                    Conférences/ateliers</A></li> 
                            <LI><A href="conferencesat.html#calendrier"> 
                                    &nbsp;&nbsp;&nbsp;-&nbsp;calendrier</A></li> 
                        </UL>
                    </LI>
                </UL>
            </TD><td>
                <UL class=niveau1>
                    <LI class="niv1">centre de documentation
                        <UL class=niveau2>
                            <LI><A href="./letpsy/"> 
                                    la lettre du psy</A></li>
                            <LI><A href="./infopsy/"> 
                                    articles de psys</A></li>
                            <LI><A href="./infopsy/sentiers.html"> 
                                    les sentiers</A></li> 
                            <LI><A href="./guide/"> 
                                    le guide des émotions</A></li> 
                            <LI><A href="./outils/"> 
                                    le coffre à outils</A></li> 
                            <LI><A href="./images/"> 
                                    images intérieures</A></li> 
                        </UL>
                    </LI>
                </UL>
            </TD>
    </TABLE>
</DIV>
        <br></font>
        <!-- 
                section aide 
        -->
        <a name="aide"></a>
        <table cellpadding="5" width="100%">

            <tr>
                <td colspan="2" bgcolor="#990066">
            <center><font color="#ffffff" size="+1"><b>Où
                    aller si vous cherchez... de l'aide psychologique?</b>
                </font></center>
            </td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Vous avez besoin de
                        psychothérapie?</b></font>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <br>
                    <font size="-1">
                    <a href="http://www.redpsy.com/therapie.html"><b>La
                            psychothérapie</b></a><br>
                    Découvrez les différentes formes de psychothérapie
                    que nous offrons: individuelle et de couple. Voyez
                    comment
                    choisir celle qui convient à vos besoins! </font>
                </td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Vous désirez
                        développer votre habileté à ressentir?</b></font></td>
                <td valign="top" width="70%" style="text-align: left"><br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/sr.html"><b>Le programme
                            d'auto-développement: Savoir Ressentir (2e édition)</b></a>
                    <br>
                    Un fascicule par jour (ou au deux jours selon ce qui vous convient),
                    30 à 50 minutes par séance, au moment, à l'endroit et au rythme qui
                    vous conviennent. S'adapte à vos habiletés, vos objectifs, vos
                    préférences et même vos réticences. <br>
                    Par les psychologues Michelle Larivey et Jean Garneau.<br>
                    <font color="RED"><b>Également
                        disponible en cours virtuels</b> </font>: <b><a href="http://www.redpsy.com/editions/sro.html">Savoir
                            Ressentir Online!</a></b>
                    </font></td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Vous voulez un
                        rendez-vous ?</b></font>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <br>
                    <font size="-1">
                    <a href="http://redpsy.com/therapie.html#rendez-vous"><b>Pour
                            rencontrer un de nos psychologues</b></a>
                    <br>
                    Voici comment procéder pour obtenir un rendez-vous avec un psychologue
                    de notre équipe. </font>
                </td>
            </tr>
            <tr>
                <td valign="top" width="30%"></td>
            </tr>

        </table>
        <br>
        <!--
                section info
        -->
        <a name="info"></a>
        <table cellpadding="5" width="100%">

            <tr>
                <td colspan="2" bgcolor="#990066">
            <center><font color="#ffffff" size="+1"><b>Où
                    aller si vous cherchez... de l'information en psychologie?</b>
                </font></center>
            </td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Un magazine
                        électronique en français sur la psychologie?</b></font>
                </td>
                <td valign="top" width="70%" style="text-align: left"><br>
                    <font size="-1"><a href="http://www.redpsy.com/letpsy"><b>La lettre du Psy</b></a><br>
                    Magazine électronique gratuit où vous trouverez des articles, des
                    réponses à vos questions,
                    la définition d'expériences émotives, des outils et des trucs utiles
                    pour vous aider dans votre développement personnel.<br>
                    L'édition de la lettre du psy est interrompue depuis quelques années. Vous pouvez encore consulter nos archives sur le site.
                    Nous espérons reprendre un jour cette formule sous une autre forme. Vous pouvez continuer à nous envoyer vos coordonnées qui nous permettrons de vous envoyer des informations concernant une parution éventuelle.
                    </font></td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1">
                    <b>Des articles pour vous aider dans votre
                        développement personnel?</b>
                    </font></td>
                <td valign="top" width="70%" style="text-align: left"><br>
                    <font size="-1">
                    <a href="http://www.redpsy.com/infopsy"><b>Infopsy</b></a><br>
                    Articles intéressants
                    et utiles concernant diverses réalités psychologiques. Pour chacun,
                    vous pouvez consulter une liste de questions-réponses et même poser vos
                    propres questions.<br>
                    Voyez aussi les livres de la <b><a href="http://www.redpsy.com/editions/">collection La lettre
                            du Psy</a></b>.
                    </font></td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Des informations pour
                        mieux comprendre vos expériences émotives?</b>
                    </font></td>
                <td valign="top" width="70%" style="text-align: left"><br>
                    <font size="-1"><a href="http://www.redpsy.com/guide"><b>Le guide des
                            émotions</b></a><br>
                    Explications précises concernant la signification et l'utilité de
                    différentes expériences émotives (culpabilité, jalousie, désir, gêne,
                    etc.). De plus, distinguez les quatre types d'expériences émotives.<br>
                    Voyez aussi le livre <a href="http://www.redpsy.com/editions/puissance.html"><b>La
                            puissance des émotions</b></a>, par Michelle Larivey.
                    </font></td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Des trucs et des
                        outils pour vous aider?</b>
                    </font></td>
                <td valign="top" width="70%" style="text-align: left">
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/outils"><b>Le coffre
                            d'outils</b></a><br>
                    Variété d'outils pour vous aider dans votre développement personnel.
                    Des outils pour
                    mieux vous connaître, améliorer votre vie de couple, apprendre des
                    techniques de communication, etc. </font>
                </td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Des poèmes qui
                        traitent de réalités psychologiques?</b></font>
                </td>
                <td valign="top" width="70%" style="text-align: left"><br>
                    <font size="-1"><a href="http://www.redpsy.com/images"><b>Images
                            intérieures</b></a><br>
                    C'est dans un langage imagé que la psychologue Michelle Larivey rend
                    avec
                    justesse les nuances, les subtilités, les éclats et l'intensité des
                    drames
                    humains que son travail l'amène à partager.<br>
                    Voyez aussi <a href="http://redpsy.com/editions/ravage.html">Ravage
                        et... délivrance</a>, un recueil de poèmes humanistes par
                    Michelle Larivey.
                    </font></td>
            </tr>

        </table>
        <br>
        <!--
                section pro
        -->
        <a name="pro"></a> <br>
        <table cellpadding="5" width="100%">

            <tr>
                <td colspan="2" bgcolor="#990066">
            <center><font color="#ffffff" size="+1"><b>Vous
                    êtes un professionnel de la santé mentale ?</b>
                </font></center>
            </td>
            </tr>
            <tr>
                <td valign="top" width="30%"></td>
                <td valign="top" width="70%" style="text-align: left">
                    <br>
                    <b><a href="http://www.redpsy.com/pro/">Nos
                            services aux professionnels</a></b>
                    <br>
                </td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Vous travaillez
                        auprès de victimes de choc post-traumatique?</b></font>
                </td>
                <td valign="top" width="70%" style="text-align: left"><br>
                    <font size="-1"><a href="http://www.redpsy.com/pro/stressec.html"><b>Le
                            stress secondaire</b></a>
                    <br>
                    Vous y trouverez des ressources pour évaluer si vous êtes
                    potentiellement à risque d'éprouver des problèmes reliés à votre
                    pratique. Vous trouverez aussi de l'aide si vous en avez besoin. </font>
                </td>
            </tr>
            <tr>
                <td valign="top" width="30%"><br>
                    <font size="-1"><b>Vous cherchez des
                        outils d'intervention?</b></font>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/pro/pad.html"><b>Utilisation
                            professionnelle du programme Savoir Ressentir </b></a>
                    <br>
                    Voici un outil qui contribue à développer chez le client des habiletés
                    qui sont essentielles au succès de la démarche thérapeutique: la
                    capacité d'éprouver et d'identifier clairement ses sentiments ainsi que
                    ses sensations et émotions. </font>
                </td>
            </tr>

        </table>
        <b><i><br>
                <br>
                <!--
                        Section des publications 
                -->
                <a name="publications"></a>&nbsp; <br>
            </i></b>
        <table width="100%">
            <tr>
                <td colspan="2" bgcolor="#990066">
            <center><font color="#ffffff" size="+1"><b>Nos publications</b>
                </font></center>
            </td>
            </tr>
            <tr>
                <td colspan="2">
            <center><br>
                <b><a href="#livres"><font color="#990066"><b>Nos livres</b></font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#prog"><font color="#990066"><b>Nos
                            programmes</b></font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="#cd"><font color="#990066"><b>Nos
                            CD (livres audio)</b></font></a></b>
                <br>
                <br>
                </td>
                </tr>
                <!-- Section des livres -->
                <tr>
                    <td colspan="2" align="left">
                        <a name="livres"></a>&nbsp;
                        <font color="#990066" size="+1"><b>Nos
                            livres</b></font>
                    </td>
                </tr>
                <!-- Livre Le défi des relations -->
                <tr>
                    <td valign="top" width="30%">
                <center><br>
                    <a href="http://www.redpsy.com/editions/transfert.html">
                        <img src="http://www.infopsy.com/red/editions/defiatu.jpg" alt="Couverture" border="1" height="136" width="90"></a>
                    <br>
                    <font size="-2"><a href="http://www.redpsy.com/editions/transfert.html#cd">Aussi
                        disponible sur CD audio</a></font></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/transfert.html"><b>Le
                            défi des relations -- Comment résoudre nos transferts affectifs</b></a>
                    <br>
                    Un ouvrage précieux pour tous ceux qui veulent mieux comprendre leurs
                    relations avec les personnes les plus importantes de leur vie et cesser
                    de se retrouver dans les mêmes impasses avec chaque nouveau partenaire.
                    Les scénarios répétitifs et les réactions disproportionnées trouvent
                    ici un sens et une utilité cruciale pour le développement de notre
                    identité. Le défi des relations propose non seulement une compréhension
                    des aspects transférentiels qui sont au coeur de ces impasses, mais
                    également la possibilité d'arriver à une véritable solution à travers
                    l'expression.<br>
                    Par Michelle Larivey, psychologue.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- Livre L'enfer de la fuite -->
                <tr>
                    <td valign="top" width="30%">
                <center><a href="http://www.redpsy.com/editions/enfer.html">
                        <img src="http://www.infopsy.com/red/editions/enferF16.jpg" alt="Couverture" border="1" height="137" width="89"></a><br>
                    <br>
                </center>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><a href="http://www.redpsy.com/editions/enfer.html"><b>L'enfer
                            de la fuite -- Comment en revenir plus fort</b></a>
                    <br>
                    Cet ouvrage s'adresse à tous ceux qui souffrent des maux découlant de
                    la fuite de soi: anxiété et angoisse, panique, phobie, migraines,
                    insomnie, stress, burnout, alcoolisme, et autres assuétudes.<br>
                    On y trouve des explications claires sans jargon technique et des
                    solutions qui ont fait leurs preuves. La compréhension des mécanismes
                    en jeu permet d'agir soi-même sur sa vie et d'y apporter des
                    changements constructifs.<br>
                    Par Jean Garneau et Michelle Larivey, avec la collaboration de Gaëtane
                    LaPlante, Karène Larocque et Bruno Roberge.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- Livre La puissance des émotions -->
                <tr>
                    <td valign="top" width="30%">
                <center><a href="http://www.redpsy.com/editions/puissance.html">
                        <img src="http://www.infopsy.com/red/bandeau/PUISS1tu.jpg" alt="Couverture" border="1" height="137" width="89"></a>
                    <br>
                    <font size="-2"><a href="http://www.redpsy.com/editions/puissance.html#cd">Aussi
                        disponible sur CD audio</a></font></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><a href="http://www.redpsy.com/editions/puissance.html"><b>La
                            puissance des émotions -- Comment distinguer les vraies des fausses</b></a>
                    <br>
                    Des clarifications essentielles sur le rôle des émotions, sur la nature
                    de chacune d'entre elles et sur la manière de s'en servir. Chaque
                    expérience émotionnelle est développée à partir d'anecdotes tirées du
                    quotidien.<br>
                    Sans jargon scientifique ou vocabulaire technique, cet ouvrage servira
                    de guide à tous ceux qui s'intéressent à leur vie émotionnelle et qui
                    désirent mieux la comprendre. <br>
                    Par la psychologue Michelle Larivey.</font>
                    <br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- Livre Les émotions source de vie -->
                <tr>
                    <td valign="top" width="30%">
                <center><a href="http://www.redpsy.com/editions/emotions.html">
                        <img src="http://www.infopsy.com/red/editions/emotionstu.jpg" alt="Couverture" border="1" height="147" width="95"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>La vie émotive
                        vous intéresse ?</b>
                    <br>
                    <br>
                    <a href="http://www.redpsy.com/editions/emotions.html">
                        <b>Les émotions source de vie</b></a>
                    <br>
                    Cet ouvrage permet de comprendre plusieurs phénomènes de la vie
                    psychique. Écrit par des spécialistes, dans un langage précis et
                    accessible, il fournit des explications fondamentales sur le
                    fonctionnement des émotions. <i>Préface de Yves St-Arnaud</i>
                    : "... <i> des points de repère précis pour laisser toute la
                        place à ses émotions sans être envahi par elles.</i> ..."
                    <br>
                    Par les psychologues Jean Garneau et Michelle Larivey; <br>
                    avec la collaboration de Gaëtane La Plante. </font>
                    <br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- Livre Ravage et... Délivrance -->
                <tr>
                    <td valign="top" width="30%">
                <center><a href="http://www.redpsy.com/editions/ravage.html"><img src="http://www.infopsy.com/red/RAVA1t.jpg" alt="Couverture" border="1" height="130" width="86"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>Vous aimez la
                        poésie ?</b>
                    <br>
                    <br>
                    <a href="http://www.redpsy.com/editions/ravage.html">
                        <b>Ravage et... Délivrance</b> (poèmes
                        humanistes)</a>
                    <br>
                    Les réalités psychologiques ont une richesse et une complexité qu'il
                    est difficile de traduire en mots. Michelle Larivey utilise souvent le
                    langage imagé de la poésie pour rendre avec justesse les nuances, les
                    subtilités, les éclats et l'intensité des drames humains que le travail
                    quotidien l'amène à partager. <i>Préface de Jacques Salomé.</i><br>
                    Par la psychologue Michelle Larivey.<br>
                    <br>
                    <br>
                    </font>
                </td>
                </tr>
                <!-- Livre Auto-développement -->
                <tr>
                    <td valign="top" width="30%">
                <center><a href="http://www.redpsy.com/editions/ad.html"><img src="http://www.infopsy.com/red/editions/autodtu.jpg" alt="Couverture" border="1" height="147" width="96"></a><br>
                </center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>Vous désirez en
                        savoir plus sur l'Auto-développement?</b>
                    <br>
                    <br>
                    <a href="http://www.redpsy.com/editions/ad.html">
                        <b>L'auto-développement: psychothérapie dans la
                            vie quotidienne</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="RED"><b>épuisé</b></font>
                    <br>
                    Synthèse de l'approche Auto-développement: une conception du
                    développement personnel, une explication du processus de croissance,
                    une possibilité d'utiliser ses relations comme occasions
                    d'épanouissement et des réflexions sur certaines questions
                    fondamentales de l'existence. <br>
                    Par les psychologues Michelle Larivey et Jean Garneau.
                    </font></td>
                </tr>
                <!-- Section des programmes -->
                <tr>
                    <td colspan="2" align="left">
                <center><img src="http://www.infopsy.com/red/barmauv.gif" height="4" width="400"></center>
                <br>
                <a name="prog"></a>&nbsp;<br>
                <font color="#990066" size="+1"><b>Nos
                    programmes d'auto-développement</b></font><br>
                <br>
                </td>
                </tr>
                <!-- Programme Savoir Ressentir -->
                <tr>
                    <td valign="top" width="30%">
                <center><br>
                    <a href="http://www.redpsy.com/editions/sr.html">
                        <img src="http://www.infopsy.com/red/RS2C.jpg" alt="Savoir Ressentir (2e édition)" border="0" height="89" width="123"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>Vous désirez
                        développer votre habileté à ressentir?</b>
                    <br>
                    <br>
                    <a href="http://www.redpsy.com/editions/sr.html">
                        <b>Le programme Savoir Ressentir (2e édition)</b></a>
                    <br>
                    Un fascicule par jour (ou au deux jours selon ce qui vous convient), 30
                    à 50 minutes par séance, au moment, à l'endroit et au rythme qui vous
                    conviennent. S'adapte à vos habiletés, vos objectifs, vos préférences
                    et même vos réticences. <br>
                    Par les psychologues Michelle Larivey et Jean Garneau.<br>
                    <font color="RED"><b>Également
                        disponible en cours virtuels</b> </font>: <b><a href="http://www.redpsy.com/editions/sro.html">Savoir
                            Ressentir Online</a></b>
                    </font><br>
                    <br>
                </td>
                </tr>
                <!-- Programme Savoir Ressentir Online -->
                <tr>
                    <td valign="top" width="30%">
                <center><br>
                    <br>
                    <br>
                    <a href="http://www.redpsy.com/editions/sro.html">
                        <img src="http://www.infopsy.com/red/editions/rs2tu.jpg" alt="Savoir Ressentir Online" border="0" height="106" width="80"></a></center>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><br>
                    <br>
                    <b>Vous voulez développer votre habileté à
                        ressentir ?</b>
                    <br>
                    <br>
                    <a href="http://www.redpsy.com/editions/sro.html">
                        <b>Savoir Ressentir Online</b> : trois
                        cours virtuels pour apprendre à ressentir!</a>
                    <br>
                    Savoir Ressentir est un programme qui vous apprendra à utiliser vos
                    sentiments et vos émotions de façon productive. Une série de trois
                    cours totalisant 24 leçons que vous suivrez au moment et au rythme qui
                    vous conviennent. Les difficultés que vous rencontrez et les résultats
                    que vous obtenez aux activités déterminent la suite de votre démarche.
                    Ce cheminement personnalisé permet de vous offrir un cours qui s'adapte
                    à vos habiletés, vos objectifs, vos préférences et même vos réticences.
                    <br>
                    Par les psychologues Jean Garneau et Michelle Larivey.
                    </font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- Section des livres audio -->
                <tr>
                    <td colspan="2" align="left">
                <center><img src="http://www.infopsy.com/red/barmauv.gif" height="4" width="400"></center>
                <br>
                <a name="cd"></a>&nbsp;<br>
                <font color="#990066" size="+1"><b>Nos
                    livres audio sur CD</b></font>
                </td>
                </tr>
                <!-- CD Stress -->
                <tr>
                    <td valign="middle" width="30%">
                    <center><!--<img src="http://www.infopsy.com/red/nouveau.gif" width="60" height="16" border="0" alt="nouveau"> --><br>
                    <br>
                    <a href="http://www.redpsy.com/editions/stress.html"><img src="http://infopsy.com/red/editions/CDstress3a.jpg" alt="Le stress" border="1" height="84" width="94"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <b>CD AUDIO-ROM</b> par <img src="http://infopsy.com/coffragants/coffragants12.GIF" alt="Coffragants" border="0" height="50" width="98">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/stress.html"><b>Le
                            stress : comment le gérer sainement</b></a>
                    <br>
                    Dans la <font color="#990066"><b>collection La
                        lettre du Psy</b></font>, ce livre audio contient l'article
                    de Jean Garneau ainsi que les réponses aux questions fréquentes qui s'y
                    rattachent. Il fournit aussi divers outils et textes complémentaires
                    permettant de s'évaluer soi-même, d'approfondir la question et de
                    maîtriser les habiletés nécessaires pour mieux gérer le stress qui fait
                    partie de notre existence. Une vision différente qui redonne sa place
                    au plaisir intense.<br>
                    <br>
                    Narration par Jean Garneau et Sophie Stanké.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- CD Jalousie -->
                <tr>
                    <td valign="middle" width="30%">
                <center><a href="http://www.redpsy.com/editions/jalousie.html"><img src="http://infopsy.com/red/editions/jal3a.jpg" alt="Jalousie amoureuse" border="0" height="84" width="94"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <b>CD AUDIO-ROM</b> par <img src="http://infopsy.com/coffragants/coffragants12.GIF" alt="Coffragants" border="0" height="50" width="98">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/jalousie.html"><b>La
                            jalousie amoureuse : comment la rendre fertile</b></a>
                    <br>
                    Dans la <font color="#990066"><b>collection La
                        lettre du Psy</b></font>, ce livre audio contient l'article
                    de Michelle Larivey ainsi que les réponses aux questions fréquentes qui
                    s'y rattachent. Il fournit aussi divers outils et textes
                    complémentaires permettant de s'évaluer soi-même, d'approfondir la
                    question et de maîtriser les habiletés requises pour utiliser sa
                    jalousie ou celle d'un proche comme tremplin vers un meilleur
                    épanouissement de soi et de la relation. Un guide pratique illustré de
                    nombreux exemples.<br>
                    <br>
                    Narration par Michelle Larivey et Alexandre Stanké.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- CD Victime -->
                <tr>
                    <td valign="middle" width="30%">
                <center><a href="http://www.redpsy.com/editions/victime.html"><img src="http://infopsy.com/red/editions/vict3a.jpg" alt="Refuser d'être victime" border="0" height="84" width="94"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>CD AUDIO-ROM</b></font>
                    par <img src="http://infopsy.com/coffragants/coffragants12.GIF" alt="Coffragants" border="0" height="50" width="98">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/victime.html"><b>Refuser
                            d'être victime : comment échapper au harcèlement</b></a>
                    <br>
                    Dans la <font color="#990066"><b>collection La
                        lettre du Psy</b></font>, ce livre audio contient l'article
                    de Michelle Larivey ainsi que les réponses aux questions fréquentes qui
                    s'y rattachent. Il fournit aussi divers outils et textes
                    complémentaires permettant de s'évaluer soi-même, d'approfondir la
                    question et de maîtriser les habiletés requises pour échapper au
                    harcèlement. Un guide pratique illustré de nombreux exemples.<br>
                    <br>
                    Narration par Michelle Larivey et Alexandre Stanké.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- CD Burnout -->
                <tr>
                    <td valign="middle" width="30%">
                <center><a href="http://www.redpsy.com/editions/burn.html"><img src="http://www.infopsy.com/red/editions/CDBURN2a.jpg" alt="CD audio Le burnout" border="1" height="84" width="94"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>CD AUDIO-ROM</b></font>
                    par <img src="http://infopsy.com/coffragants/coffragants12.GIF" alt="Coffragants" border="0" height="50" width="98">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/burn.html"><b>L'épuisement professionnel : prévention et solutions</b></a>
                    <br>
                    Dans la <font color="#990066"><b>collection La
                        lettre du Psy</b></font>, ce livre audio contient l'article
                    de Jean Garneau sur <b>l'épuisement professionnel</b>
                    ainsi que les réponses aux questions fréquentes qui s'y rattachent. Il
                    propose aussi divers outils et textes complémentaires permettant de
                    s'évaluer soi-même, d'approfondir la question et de prévenir le congé
                    forcé. À ceux qui sont déjà atteints et à leurs proches, il fournit un
                    guide pour comprendre ce qui se passe et y apporter des solutions
                    durables.<br>
                    <br>
                    Narration par Jean Garneau et Sophie Stanké.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- CD Confiance -->
                <tr>
                    <td valign="middle" width="30%">
                <center><br>
                    <br>
                    <a href="http://www.redpsy.com/editions/conf.html"><img src="http://www.infopsy.com/red/editions/CDCONF2a.jpg" alt="CD audio Angoisse et anxiété" border="1" height="81" width="94"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>CD AUDIO-ROM</b></font>
                    par <img src="http://Infopsy.com/pocketaudio/pkau3.gif" alt="POCKETAUDIO" border="0" height="10" width="93">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/conf.html"><b>La
                            confiance en soi : comment la bâtir au quotidien</b></a>
                    <br>
                    Dans la <font color="#990066"><b>collection La
                        lettre du Psy</b></font>, ce livre audio contient l'article
                    de Jean Garneau ainsi que les réponses aux questions fréquentes qui s'y
                    rattachent. Il fournit aussi divers outils et textes complémentaires
                    permettant de s'évaluer soi-même, d'approfondir la question et de
                    maîtriser les habiletés requises pour devenir plus confiant. Un guide
                    pratique et concret pour bâtir sa confiance. <br>
                    <br>
                    Narration par Jean GarneauLarivey et Sophie Stanké.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- CD Angoisse et anxiété -->
                <tr>
                    <td valign="middle" width="30%">
                <center><br>
                    <br>
                    <a href="http://www.redpsy.com/editions/anx.html"><img src="http://www.infopsy.com/red/editions/CDANG2a.jpg" alt="CD audio Angoisse et anxiété" border="1" height="82" width="94"></a></center>
                <br>
                <br>
                </td>
                <td valign="top" width="70%" style="text-align: left">
                    <font size="-1"><b>CD AUDIO-ROM</b></font>
                    par <img src="http://Infopsy.com/pocketaudio/pkau3.gif" alt="POCKETAUDIO" border="0" height="10" width="93">
                    <br>
                    <br>
                    <font size="-1"><a href="http://www.redpsy.com/editions/anx.html"><b>Angoisse
                            et anxiété : Les vigiles de l'équilibre mental </b></a>
                    <br>
                    Premier titre de la <font color="#990066"><b>collection
                        La lettre du Psy</b></font>, ce livre audio contient
                    l'article de Michelle Larivey sur l'angoisse ainsi que les réponses aux
                    questions fréquentes qui s'y rattachent. Il fournit également divers
                    outils et textes complémentaires permettant d'approfondir la question
                    et de maîtriser les habiletés requises. <br>
                    <br>
                    Narration par Martine Mignot et Alexandre Stanké.</font><br>
                    <br>
                    <br>
                </td>
                </tr>
                <!-- ici - ici - ici - ici - ici - ici - ici - ici - ici - ici - ici -->

        </table>
    </center>
    <!-- Fin de la section des publications -->
    <center>
        <center>
            <!-- Footer --><br>
            <img src="http://www.infopsy.com/red/barmauv.gif" alt="psychologues humanistes Montréal" height="5" width="600"></center>
        <table width="85%">

            <tr>
                <td align="left">
                    <a href="http://www.redpsy.com/index.html"><img src="http://www.infopsy.com/red/redlogoc.gif" alt="psychologues humanistes Montréal" border="0" height="42" hspace="5" vspace="5" width="49"></a></td>
                <td><font size="-1">
                    Tous droits réservés © 1997-2016 par Ressources en Développement inc.
                    <br>
                    Nous n'exprimons aucune opinion concernant les <a href="http://redpsy.com/google.shtml">annonces google</a><br>
                    Si vous voulez reproduire ou distribuer ce document, lisez <a href="http://www.redpsy.com/copyright.html">ceci</a>
                    </font></td>
            </tr>

        </table>
    </center>
</td>
</tr>

</table>
</center>
</body>
</html>
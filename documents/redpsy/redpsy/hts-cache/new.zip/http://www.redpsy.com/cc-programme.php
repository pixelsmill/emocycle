<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Achat du coffret Savoir Ressentir</title>
        <style>
            .achatcc {
                display: block;
            }
            #produits, th, td {
                margin: auto;
                border: none;
            }
            #produits td {
                padding-left: 25px;
                padding-right: 25px;
            }
        </style>
                <link rel="stylesheet" type="text/css" href="/sept2016/normal.css">
        <script>
            function jemail(user, domain, suffix){
                document.write('<a href="' + 'mailto:' + user + '@' + domain + '.' + suffix + '">' + user + '@' + domain + '.' + suffix + '</a>');
            }
        </script>
    </head>
    <body>
        <div id="contenant">
            <div id="entete">
                <a href='/index.php'><img class="logo" src="http://www.infopsy.com/red/bandeau/logo/redediteur.jpg"
                    style="border-style: none" alt="Logo ReD éditeur" height="69" width="441"></a>
                <p class="red">
                    Ressources en Développement<br>
                    Les psychologues humanistes
                </p>
                <img class="barmauv" src="http://www.infopsy.com/red/barmauv.gif" height="3" width="300" alt="---------------">
            </div>
    <div id="colndroite">
    </div>
    <div id="contenu">
        <div id="titre">
            <h1> Coffret Savoir Ressentir </h1>
            <h3>Payable par carte bancaire</h3>
        </div>
        <!-- ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici -->
<br>
<noscript><h2> ATTENTION<br>
    !!! Pour le calcul de la commande, JavaScript doit être activé !!!</h2>
</noscript>
<!-- Commande-->
<div style="margin-left: 100px;">
	<!--
// déplacer la fin de commentaire à la fin pour un message nul,
//	ou après cette ligne pour l'afficher.
<br>
<font color="RED" size="+1">IMPORTANT :
Pour la période du 7 juin au 29 juillet, les commandes
seront expédiées une fois par semaine seulement.</font>
<br>
</font>
-->

</div>
	<br>
    <form id="nombres" action="achats/cc-achat.php" method="post">
            <h2>Entrez le nombre d'exemplaires que vous désirez</h2>
            <table id="produits" border="1">
                <tr><th>nombre</th>
                    <th>item</th>
                    <th>prix/unité</th></tr> 
	    <tr><td><input name= "nombre1" size="3" value="0" type="text"></td>
<input type="hidden" name="prod1" value="13"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/sr.html" target="_self">Prog.Savoir ressentir 2e édition</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>225.00 $CAN</td></tr>

<input type="hidden" name="nbprod" value="1">
	</table>
	<br>
	<br>
        <h2><input value="Calculer le total" type="submit"></h2>
        </form>
    </div>
                <div id="ventecc" class="achatcc">
                <p class="accept"><b>Nous acceptons:</b><br>
                <img id="cartes" src="http://www.redpsy.com/images/logosCC.jpg" alt="Visa, Master Card, Am.Express"><br>
                    <a href="http://www.redpsy.com/cc-securite.html">
                        Nos politiques pour les cartes de crédit</a><br></p>
                    <p class="prob">Si vous éprouvez des difficultés avec votre commande, <br>
                    vous pouvez communiquer rapidement avec nous à cette adresse: <br>
                    <script>
                        <!-- Begin
                        jemail("commandes", "infopsy", "com");
                        // End -->
                    </script>
                </p>
            </div>
            <div id="pied"><br>
                <center><a href="#"><img src="http://www.infopsy.com/red/1mup.gif" border="0"></a></center>
                <img class="barfin" src="http://www.infopsy.com/red/barmauv.gif" height="5" width="500" alt="---------------">
                <div id="copyright">
                    <img src="http://www.infopsy.com/red/redlogoc.gif" alt="ReD" width="49">
                    <div id="droits"><p class="droits">
                            Tous droits réservés © 2000-2016 par Ressources en Développement
                        </p></div>
                </div>
            </div>
        </div>    
    </body>
</html>

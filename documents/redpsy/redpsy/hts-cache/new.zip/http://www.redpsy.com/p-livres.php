<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Achat de livres</title>
        <style>
            .achatcc {
                display: block;
            }
            #produits, th, td {
                margin: auto;
                border: none;
            }
            #produits td {
                padding-left: 25px;
                padding-right: 25px;
            }
        </style>
                <link rel="stylesheet" type="text/css" href="/sept2016/normal.css">
        <script>
            function jemail(user, domain, suffix){
                document.write('<a href="' + 'mailto:' + user + '@' + domain + '.' + suffix + '">' + user + '@' + domain + '.' + suffix + '</a>');
            }
        </script>
    </head>
    <body>
        <div id="contenant">
            <div id="entete">
                <a href='/index.php'><img class="logo" src="http://www.infopsy.com/red/bandeau/logo/redediteur.jpg"
                    style="border-style: none" alt="Logo ReD éditeur" height="69" width="441"></a>
                <p class="red">
                    Ressources en Développement<br>
                    Les psychologues humanistes
                </p>
                <img class="barmauv" src="http://www.infopsy.com/red/barmauv.gif" height="3" width="300" alt="---------------">
            </div>
    <div id="colndroite">
    </div>
    <div id="contenu">
        <div id="titre">
            <h1> Achat par la poste </h1>
            <h3>Payable par chèque ou carte bancaire</h3>
        </div>
        <!-- ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici  ici -->
<br>
<noscript><h2> ATTENTION<br>
    !!! Pour le calcul de la commande, JavaScript doit être activé !!!</h2>
</noscript>
<!-- Commande-->
		<br>
    <form id="nombres" action="achats/p-achat.php" method="post">
            <h2>Entrez le nombre d'exemplaires que vous désirez</h2>
            <table id="produits" border="1">
                <tr><th>nombre</th>
                    <th>item</th>
                    <th>prix/unité</th></tr> 
	    <tr><td><input name= "nombre1" size="3" value="0" type="text"></td>
<input type="hidden" name="prod1" value="0"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/emotions.html" target="_self">Livre: Les émotions source de vie</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>29.00 $CAN</td></tr>

<tr><td><input name= "nombre2" size="3" value="0" type="text"></td>
<input type="hidden" name="prod2" value="1"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/enfer.html" target="_self">Livre: L'enfer de la fuite</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>29.95 $CAN</td></tr>

<tr><td><input name= "nombre3" size="3" value="0" type="text"></td>
<input type="hidden" name="prod3" value="2"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/puissance.html" target="_self">Livre: La puissance des émotions</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>26.95 $CAN</td></tr>

<tr><td><input name= "nombre4" size="3" value="0" type="text"></td>
<input type="hidden" name="prod4" value="3"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/transfert.html" target="_self">Livre: Le défi des relations</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>24.95 $CAN</td></tr>

<tr><td><input name= "nombre5" size="3" value="0" type="text"></td>
<input type="hidden" name="prod5" value="4"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/puissance.html#cd" target="_self">2 CD audio: La puissance des émotions</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>21.95 $CAN</td></tr>

<tr><td><input name= "nombre6" size="3" value="0" type="text"></td>
<input type="hidden" name="prod6" value="5"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/anx.html" target="_self">CD audio: Angoisse et anxiété</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>19.95 $CAN</td></tr>

<tr><td><input name= "nombre7" size="3" value="0" type="text"></td>
<input type="hidden" name="prod7" value="6"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/conf.html" target="_self">CD audio: La confiance en soi</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>19.95 $CAN</td></tr>

<tr><td><input name= "nombre8" size="3" value="0" type="text"></td>
<input type="hidden" name="prod8" value="7"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/burn.html" target="_self">CD audio: L'épuisement professionnel</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>18.95 $CAN</td></tr>

<tr><td><input name= "nombre9" size="3" value="0" type="text"></td>
<input type="hidden" name="prod9" value="8"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/victime.html" target="_self">CD audio: Refuser d'être victime</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>18.95 $CAN</td></tr>

<tr><td><input name= "nombre10" size="3" value="0" type="text"></td>
<input type="hidden" name="prod10" value="9"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/jalousie.html" target="_self">CD audio: La jalousie amoureuse</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>18.95 $CAN</td></tr>

<tr><td><input name= "nombre11" size="3" value="0" type="text"></td>
<input type="hidden" name="prod11" value="10"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/stress.html" target="_self">CD audio: Le stress</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>18.95 $CAN</td></tr>

<tr><td><input name= "nombre12" size="3" value="0" type="text"></td>
<input type="hidden" name="prod12" value="11"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/transfert.html" target="_self">CD audio: Le défi des relations</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>22.95 $CAN</td></tr>

<tr><td><input name= "nombre13" size="3" value="0" type="text"></td>
<input type="hidden" name="prod13" value="12"><td><div size="-1"><b>
<a href="http://redpsy.com/editions/ravage.html" target="_self">Livre: Ravage et délivrance</a></b><br>
<div style="color:RED"><b></b></div></td>
<td>16.00 $CAN</td></tr>

<input type="hidden" name="nbprod" value="13">
	</table>
	<br>
	<br>
        <h2><input value="Calculer le total" type="submit"></h2>
        </form>
    </div>
                <div id="ventecc" class="achatcc">
                <p class="accept"><b>Nous acceptons:</b><br>
                <img id="cartes" src="http://www.redpsy.com/images/logosCC.jpg" alt="Visa, Master Card, Am.Express"><br>
                    <a href="http://www.redpsy.com/cc-securite.html">
                        Nos politiques pour les cartes de crédit</a><br></p>
                    <p class="prob">Si vous éprouvez des difficultés avec votre commande, <br>
                    vous pouvez communiquer rapidement avec nous à cette adresse: <br>
                    <script>
                        <!-- Begin
                        jemail("commandes", "infopsy", "com");
                        // End -->
                    </script>
                </p>
            </div>
            <div id="pied"><br>
                <center><a href="#"><img src="http://www.infopsy.com/red/1mup.gif" border="0"></a></center>
                <img class="barfin" src="http://www.infopsy.com/red/barmauv.gif" height="5" width="500" alt="---------------">
                <div id="copyright">
                    <img src="http://www.infopsy.com/red/redlogoc.gif" alt="ReD" width="49">
                    <div id="droits"><p class="droits">
                            Tous droits réservés © 2000-2016 par Ressources en Développement
                        </p></div>
                </div>
            </div>
        </div>    
    </body>
</html>
